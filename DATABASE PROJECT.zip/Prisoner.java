package P19;

public class Prisoner {
    private int id;
    private String name;
    private String gender;
    private String officerInCharge;
    private String crimes;
    private String courtDate;
    private boolean isDangerous;

    // Constructor
    public Prisoner(int id, String name, String gender, String officerInCharge, String crimes, String courtDate, boolean isDangerous) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.officerInCharge = officerInCharge;
        this.crimes = crimes;
        this.courtDate = courtDate;
        this.isDangerous = isDangerous;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public String getOfficerInCharge() {
        return officerInCharge;
    }

    public String getCrimes() {
        return crimes;
    }

    public String getCourtDate() {
        return courtDate;
    }

    public boolean isDangerous() {
        return isDangerous;
    }

    // Setters (if needed for updates, though not directly used in this version)
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setOfficerInCharge(String officerInCharge) {
        this.officerInCharge = officerInCharge;
    }

    public void setCrimes(String crimes) {
        this.crimes = crimes;
    }

    public void setCourtDate(String courtDate) {
        this.courtDate = courtDate;
    }

    public void setDangerous(boolean dangerous) {
        isDangerous = dangerous;
    }

    @Override
    public String toString() {
        return "ID: " + id + " | Name: " + name + " | Gender: " + gender + "\n" +
               "Crime: " + crimes + "\n" +
               "Officer: " + officerInCharge + "\n" +
               "Court Date: " + courtDate + "\n" +
               "Dangerous: " + (isDangerous ? "YES" : "NO");
    }
}
