package P19;

import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PRISONERFORM {
    JFrame frame = new JFrame("Add New Prisoner");

    JLabel idLabel = new JLabel("ID:");
    JLabel nameLabel = new JLabel("Name:");
    JLabel genderLabel = new JLabel("Gender:");
    JLabel officerLabel = new JLabel("Officer In Charge:");
    JLabel crimesLabel = new JLabel("Crimes (comma-separated):");
    JLabel courtDateLabel = new JLabel("Court Date:");
    JCheckBox dangerousCheckBox = new JCheckBox("Is Dangerous?");

    JTextField idField = new JTextField();
    JTextField nameField = new JTextField();
    JTextField genderField = new JTextField();
    JTextField officerField = new JTextField();
    JTextArea crimesArea = new JTextArea();
    JTextField courtDateField = new JTextField();

    JButton saveButton = new JButton("Save");
    JButton cancelButton = new JButton("Cancel");

    private Formll mainForm;

    public PRISONERFORM(Formll mainForm) {
        this.mainForm = mainForm;
        frame.setSize(450, 450);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        idLabel.setBounds(30, 30, 150, 25);
        idField.setBounds(180, 30, 200, 25);

        nameLabel.setBounds(30, 70, 150, 25);
        nameField.setBounds(180, 70, 200, 25);

        genderLabel.setBounds(30, 110, 150, 25);
        genderField.setBounds(180, 110, 200, 25);

        crimesLabel.setBounds(30, 150, 150, 25);
        crimesArea.setBounds(180, 150, 200, 60);
        crimesArea.setLineWrap(true);
        crimesArea.setWrapStyleWord(true);
        JScrollPane crimesScrollPane = new JScrollPane(crimesArea);
        crimesScrollPane.setBounds(180, 150, 200, 60);

        officerLabel.setBounds(30, 220, 150, 25);
        officerField.setBounds(180, 220, 200, 25);

        courtDateLabel.setBounds(30, 260, 150, 25);
        courtDateField.setBounds(180, 260, 200, 25);

        dangerousCheckBox.setBounds(30, 300, 150, 25);

        saveButton.setBounds(50, 350, 100, 30);
        cancelButton.setBounds(200, 350, 100, 30);

        frame.add(idLabel);
        frame.add(idField);
        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(genderLabel);
        frame.add(genderField);
        frame.add(crimesLabel);
        frame.add(crimesScrollPane);
        frame.add(officerLabel);
        frame.add(officerField);
        frame.add(courtDateLabel);
        frame.add(courtDateField);
        frame.add(dangerousCheckBox);

        frame.add(saveButton);
        frame.add(cancelButton);

        addListeners();

        frame.setVisible(true);
    }

    private void addListeners() {
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                savePrisoner();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
    }

    private void savePrisoner() {
        String idStr = idField.getText().trim();
        String name = nameField.getText().trim();
        String gender = genderField.getText().trim();
        String crimes = crimesArea.getText().trim();
        String officer = officerField.getText().trim();
        String courtDate = courtDateField.getText().trim();
        boolean isDangerous = dangerousCheckBox.isSelected();

        if (idStr.isEmpty() || name.isEmpty() || gender.isEmpty() || crimes.isEmpty() || officer.isEmpty() || courtDate.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int id = Integer.parseInt(idStr);

            Connection conn = null;
            PreparedStatement pstmt = null;
            try {
                conn = DBConnection.getConnection();
                if (doesPrisonerExist(conn, id)) {
                    JOptionPane.showMessageDialog(frame, "Prisoner with ID " + id + " already exists. Please use a different ID.", "Duplicate ID", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                String sql = "INSERT INTO prisoners (id, name, gender, officer_in_charge, crimes, court_date, is_dangerous) VALUES (?, ?, ?, ?, ?, ?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, id);
                pstmt.setString(2, name);
                pstmt.setString(3, gender);
                pstmt.setString(4, officer);
                pstmt.setString(5, crimes);
                pstmt.setString(6, courtDate);
                pstmt.setBoolean(7, isDangerous);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(frame, "Prisoner record added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    frame.dispose();
                    if (mainForm != null) {
                        mainForm.clearFields();
                        mainForm.getEventH().viewAllRecords(); // Call the public method
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Failed to add prisoner record.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Database error adding prisoner: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            } finally {
                DBConnection.closeConnection(pstmt);
                DBConnection.closeConnection(conn);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format. Please enter a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Checks if a prisoner with the given ID already exists in the database.
     * @param conn The database connection.
     * @param id The ID to check.
     * @return true if a prisoner with the ID exists, false otherwise.
     * @throws SQLException if a database access error occurs.
     */
    private boolean doesPrisonerExist(Connection conn, int id) throws SQLException {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            String sql = "SELECT COUNT(*) FROM prisoners WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        } finally {
            DBConnection.closeConnection(rs);
            DBConnection.closeConnection(pstmt);
        }
    }
}