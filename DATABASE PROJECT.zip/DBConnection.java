package P19;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DBConnection {
    
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/prison_records?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root"; // Your database username
    private static final String PASSWORD = "root4230"; // <--- IMPORTANT: Ensure this is your correct MySQL root password

    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
            System.out.println("Database connected successfully!");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "MySQL JDBC Driver not found. Add it to your classpath.", "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Failed to connect to database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return connection;
    }

    /**
     * Closes the given database connection.
     * @param connection The Connection object to close.
     */
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                System.err.println("Error closing database connection: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    /**
     * Closes the given PreparedStatement.
     * @param pstmt The PreparedStatement object to close.
     */
    public static void closeConnection(PreparedStatement pstmt) {
        if (pstmt != null) {
            try {
                pstmt.close();
                System.out.println("PreparedStatement closed.");
            } catch (SQLException e) {
                System.err.println("Error closing PreparedStatement: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    /**
     * Closes the given ResultSet.
     * @param rs The ResultSet object to close.
     */
    public static void closeConnection(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
                System.out.println("ResultSet closed.");
            } catch (SQLException e) {
                System.err.println("Error closing ResultSet: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Connection conn = DBConnection.getConnection();
        if (conn != null) {
            DBConnection.closeConnection(conn);
        }
    }
}