package P19;

import java.awt.event.*;
import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EVENTH extends MouseAdapter {
    Formll mf;

    public EVENTH(Formll f) {
        mf = f;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == mf.b1) {  // Search Record
            String idStr = mf.getPrisonerID();
            String name = mf.getPrisonerName();

            if (idStr.isEmpty() || name.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter both ID and Name.", "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                int id = Integer.parseInt(idStr);
                searchPrisoner(id, name);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid ID format. Please enter a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }

        } else if (e.getSource() == mf.b2) {  // Clear
            mf.clearFields();

        } else if (e.getSource() == mf.b3) { // Check Court Date
            String courtDate = mf.getLastCourtDate();
            if (courtDate != null && !courtDate.isEmpty()) {
                JOptionPane.showMessageDialog(null, courtDate, "Court Date", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No court date available. Search for a prisoner first.", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (e.getSource() == mf.b4) {  // Add New Prisoner (Opens PRISONERFORM)
            new PRISONERFORM(mf); // Pass Formll instance to allow refreshing after adding
        } else if (e.getSource() == mf.b5) {  // Exit
            System.exit(0);
        } else if (e.getSource() == mf.b6) {  // View All Records
            viewAllRecords();
        }
    }

    /**
     * Searches for a prisoner in the database by ID and Name.
     * @param id The prisoner ID.
     * @param name The prisoner name.
     */
    private void searchPrisoner(int id, String name) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT id, name, gender, officer_in_charge, crimes, court_date, is_dangerous FROM prisoners WHERE id = ? AND name LIKE ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.setString(2, name);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                mf.setGender(rs.getString("gender"));
                mf.setOfficer(rs.getString("officer_in_charge"));
                mf.setCrimes(rs.getString("crimes"));
                mf.setLastCourtDate(rs.getString("court_date"));
                boolean isDangerous = rs.getBoolean("is_dangerous");

                JOptionPane.showMessageDialog(null, "Record found for " + rs.getString("name") + ".", "Record Found", JOptionPane.INFORMATION_MESSAGE);
                if (isDangerous) {
                    JOptionPane.showMessageDialog(null, "⚠️ WARNING: " + rs.getString("name") + " is HIGHLY DANGEROUS!", "Danger Alert", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No record found for ID: " + id + " and Name: " + name + ".", "No Record", JOptionPane.INFORMATION_MESSAGE);
                mf.clearFields();
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database error during search: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            DBConnection.closeConnection(rs);
            DBConnection.closeConnection(pstmt);
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Fetches and displays all prisoner records from the database.
     */
    public void viewAllRecords() { // Changed to public
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        StringBuilder allRecords = new StringBuilder();
        allRecords.append("📋 ALL PRISONER RECORDS:\n\n");

        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT id, name, gender, crimes, officer_in_charge, court_date, is_dangerous FROM prisoners ORDER BY id ASC";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            boolean foundAny = false;
            while (rs.next()) {
                foundAny = true;
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String gender = rs.getString("gender");
                String crimes = rs.getString("crimes");
                String officer = rs.getString("officer_in_charge");
                String courtDate = rs.getString("court_date");
                boolean isDangerous = rs.getBoolean("is_dangerous");

                allRecords.append("ID: ").append(id).append(" | Name: ").append(name).append(" | Gender: ").append(gender).append("\n");
                allRecords.append("Crime: ").append(crimes).append("\n");
                allRecords.append("Officer: ").append(officer).append("\n");
                allRecords.append("Court Date: ").append(courtDate).append("\n");
                allRecords.append("Dangerous: ").append(isDangerous ? "YES" : "NO").append("\n");
                allRecords.append("------------------------------\n");
            }

            if (!foundAny) {
                allRecords.append("No records found in the database.\n");
            }

            JTextArea textArea = new JTextArea(allRecords.toString());
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new java.awt.Dimension(500, 300));

            JOptionPane.showMessageDialog(null, scrollPane, "All Prisoner Records", JOptionPane.PLAIN_MESSAGE);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database error viewing all records: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            DBConnection.closeConnection(rs);
            DBConnection.closeConnection(pstmt);
            DBConnection.closeConnection(conn);
        }
    }
}