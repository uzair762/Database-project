package P19;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Formll {
    JFrame f1 = new JFrame("Prisoner Crime Record Lookup");

    JLabel l1 = new JLabel("Enter Prisoner ID:");
    JLabel l2 = new JLabel("Enter Prisoner Name:");
    JLabel lGender = new JLabel("Gender:");
    JLabel l3 = new JLabel("Officer In Charge:");
    JLabel l4 = new JLabel("Crimes:");

    JTextField t1 = new JTextField();
    JTextField t2 = new JTextField();
    JTextField tGender = new JTextField();
    JTextField t3 = new JTextField();
    JTextArea t4 = new JTextArea();

    JButton b1 = new JButton("Search Record");
    JButton b2 = new JButton("Clear");
    JButton b3 = new JButton("Check Court Date");
    JButton b4 = new JButton("Add New Prisoner");
    JButton b5 = new JButton("Exit");
    JButton b6 = new JButton("View All Records");

    String lastCourtDate = "";
    private EVENTH eventHandler; // Store reference to EVENTH

    public Formll() {
        f1.setSize(600, 450);
        f1.setLayout(null);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLocationRelativeTo(null);

        l1.setBounds(30, 30, 140, 30);
        l2.setBounds(30, 70, 140, 30);
        lGender.setBounds(30, 110, 140, 30);
        l3.setBounds(30, 150, 140, 30);
        l4.setBounds(30, 190, 140, 30);

        t1.setBounds(180, 30, 300, 30);
        t2.setBounds(180, 70, 300, 30);
        tGender.setBounds(180, 110, 300, 30);
        t3.setBounds(180, 150, 300, 30);
        t4.setBounds(180, 190, 300, 80);

        tGender.setEditable(false);
        t3.setEditable(false);
        t4.setEditable(false);
        t4.setLineWrap(true);
        t4.setWrapStyleWord(true);

        b1.setBounds(30, 290, 140, 30);
        b2.setBounds(180, 290, 140, 30);
        b3.setBounds(330, 290, 180, 30);
        b4.setBounds(30, 340, 180, 30);
        b5.setBounds(330, 340, 80, 30);
        b6.setBounds(430, 340, 140, 30);

        f1.add(l1); f1.add(t1);
        f1.add(l2); f1.add(t2);
        f1.add(lGender); f1.add(tGender);
        f1.add(l3); f1.add(t3);
        f1.add(l4); f1.add(t4);

        f1.add(b1); f1.add(b2); f1.add(b3);
        f1.add(b4); f1.add(b5); f1.add(b6);

        eventHandler = new EVENTH(this);
        b1.addMouseListener(eventHandler);
        b2.addMouseListener(eventHandler);
        b3.addMouseListener(eventHandler);
        b4.addMouseListener(eventHandler);
        b5.addMouseListener(eventHandler);
        b6.addMouseListener(eventHandler);

        f1.setVisible(true);
    }

    String getPrisonerID() {
        return t1.getText().trim();
    }

    String getPrisonerName() {
        return t2.getText().trim();
    }

    void setGender(String gender) {
        tGender.setText(gender);
    }

    void setOfficer(String officer) {
        t3.setText(officer);
    }

    void setCrimes(String crimes) {
        t4.setText(crimes);
    }

    void setLastCourtDate(String date) {
        lastCourtDate = date;
    }

    String getLastCourtDate() {
        return lastCourtDate;
    }

    void clearFields() {
        t1.setText("");
        t2.setText("");
        tGender.setText("");
        t3.setText("");
        t4.setText("");
        lastCourtDate = "";
    }

    public EVENTH getEventH() {
        return eventHandler;
    }
}