
CREATE DATABASE IF NOT EXISTS prison_records;


USE prison_records;


DROP TABLE IF EXISTS prisoners;

CREATE TABLE prisoners (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    officer_in_charge VARCHAR(100),
    crimes TEXT,
    court_date VARCHAR(50),
    is_dangerous BOOLEAN DEFAULT FALSE
);

INSERT INTO prisoners (id, name, gender, officer_in_charge, crimes, court_date, is_dangerous) VALUES
(101, 'Jahan Khan', 'Male', 'Officer Tabahi', 'Bank robbery', 'July 5, 2025', TRUE),
(102, 'Alina', 'Female', 'Officer Rashid', 'Cybercrime', 'July 6, 2025', TRUE),
(103, 'Babar', 'Male', 'Officer Rehman', 'Theft', 'July 7, 2025', TRUE),
(104, 'Sara', 'Female', 'Officer Zia', 'Fraud', 'July 8, 2025', TRUE),
(105, 'Usman', 'Male', 'Officer Tariq', 'Assault', 'July 9, 2025', TRUE),
(106, 'Fatima', 'Female', 'Officer Sana', 'Kidnapping', 'July 10, 2025', TRUE),
(107, 'Ahmed', 'Male', 'Officer Bilal', 'Arson', 'July 11, 2025', TRUE),
(108, 'Zoya', 'Female', 'Officer Noman', 'Hacking', 'July 12, 2025', TRUE),
(109, 'Hassan', 'Male', 'Officer Rauf', 'Smuggling', 'July 13, 2025', TRUE),
(110, 'Mina', 'Female', 'Officer Shazia', 'Drug Trafficking', 'July 14, 2025', TRUE),
(111, 'Khalid', 'Male', 'Officer Noman', 'Bribery', 'July 15, 2025', FALSE),
(112, 'Mehwish', 'Female', 'Officer Sana', 'Forgery', 'July 16, 2025', TRUE),
(113, 'Zain', 'Male', 'Officer Tabahi', 'Murder', 'July 17, 2025', TRUE),
(114, 'Iram', 'Female', 'Officer Zia', 'Cybercrime', 'July 18, 2025', TRUE),
(115, 'Talha', 'Male', 'Officer Tariq', 'Terrorism', 'July 19, 2025', TRUE),
(116, 'Laiba', 'Female', 'Officer Bilal', 'Pickpocketing', 'July 20, 2025', FALSE),
(117, 'Rehan', 'Male', 'Officer Rehman', 'Illegal Weapons', 'July 21, 2025', TRUE),
(118, 'Noor', 'Female', 'Officer Rauf', 'Human Trafficking', 'July 22, 2025', TRUE),
(119, 'Sami', 'Male', 'Officer Rashid', 'Forgery', 'July 23, 2025', FALSE),
(120, 'Anaya', 'Female', 'Officer Shazia', 'Hacking', 'July 24, 2025', TRUE);


SELECT * FROM prisoners;


SELECT * FROM prisoners WHERE id = 101;

-- Query : Select prisoners by gender
SELECT * FROM prisoners WHERE gender = 'Female';

-- Query : Select prisoners who are dangerous
SELECT * FROM prisoners WHERE is_dangerous = TRUE;

-- Query : Update a prisoner's court date
UPDATE prisoners SET court_date = 'August 1, 2025' WHERE id = 101;

-- Query  Delete a prisoner by ID (use with caution!)
-- DELETE FROM prisoners WHERE id = 100;

-- Query : Count the total number of prisoners
SELECT COUNT(*) FROM prisoners;

-- Query : Find prisoners whose name starts with 'A'
SELECT * FROM prisoners WHERE name LIKE 'A%';

-- Query : Select prisoners with a specific officer in charge
SELECT * FROM prisoners WHERE officer_in_charge = 'Officer Rashid';

-- Query : Select prisoners ordered by name
SELECT * FROM prisoners ORDER BY name ASC;

SELECT * FROM prisoners WHERE gender = 'Male';
SELECT * FROM prisoners WHERE gender = 'Female';


SELECT * FROM prisoners 
WHERE crimes LIKE '%Cybercrime%' OR crimes LIKE '%Hacking%';


SELECT * FROM prisoners WHERE court_date LIKE 'July%2025';


SELECT officer_in_charge, COUNT(*) AS prisoner_count
FROM prisoners
GROUP BY officer_in_charge
ORDER BY prisoner_count DESC;


SELECT * FROM prisoners
ORDER BY STR_TO_DATE(court_date, '%M %e, %Y') ASC;


SELECT * FROM prisoners WHERE is_dangerous = FALSE;


SELECT * FROM prisoners WHERE crimes LIKE '%Drug%';


SELECT * FROM prisoners
ORDER BY STR_TO_DATE(court_date, '%M %e, %Y') ASC
LIMIT 5;


SELECT * FROM prisoners 
WHERE officer_in_charge IN ('Officer Zia', 'Officer Rashid');


SELECT gender, COUNT(*) AS total_dangerous
FROM prisoners
WHERE is_dangerous = TRUE
GROUP BY gender;

