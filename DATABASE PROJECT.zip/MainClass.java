package P19;
import javax.swing.SwingUtilities; // Import SwingUtilities

public class MainClass {
    public static void main(String[] args) {
        // Ensure the Swing UI is created on the Event Dispatch Thread
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Formll();
            }
        });
    }
}